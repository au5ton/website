/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef POTENTCALCULATOR_PRIVATE_H
#define POTENTCALCULATOR_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.7.4.281"
#define VER_MAJOR	0
#define VER_MINOR	7
#define VER_RELEASE	4
#define VER_BUILD	281
#define COMPANY_NAME	"Potent"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	""
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"srchub.org/p/pcalculator"
#define PRODUCT_NAME	"Potent Calculator"
#define PRODUCT_VERSION	""

#endif /*POTENTCALCULATOR_PRIVATE_H*/
